import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  message: string;
  constructor(public authService: AuthService) { 

  }
  login(username: HTMLInputElement, password:HTMLInputElement, type:HTMLInputElement):boolean{
    // authservice login method
    this.message="";
    if(this.authService.login(username.value, password.value, type.value)){
      return true;
    }
  }

  logout(){
    this.authService.logout();
    // navigate programmatically to home as well
  }

ngOnInit() {
}

}


