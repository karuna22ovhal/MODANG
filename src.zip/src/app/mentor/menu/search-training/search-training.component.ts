import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-training',
  templateUrl: './search-training.component.html',
  styleUrls: ['./search-training.component.css']
})
export class SearchTrainingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
