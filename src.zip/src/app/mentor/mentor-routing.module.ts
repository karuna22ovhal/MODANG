import { NgModule } from '@angular/core';
import { Routes,RouterModule} from '@angular/router';
import { MenuComponent } from './menu/menu.component';
import {EditskillComponent} from './menu/editskill/editskill.component';
import { SearchTrainingComponent } from './menu/search-training/search-training.component';
import { NotificationsComponent } from './menu/notifications/notifications.component';
import { CompletedTrainingComponent } from './menu/completed-training/completed-training.component';
import { CurrentTrainingComponent } from './menu/current-training/current-training.component';
const routes:Routes=[
    {
        path:'mentormenu',component:MenuComponent,
        children:[
            {
                path:'editskill',component:EditskillComponent
            },
            {
                path:'searchtraining',component:SearchTrainingComponent
            },
            {
                path:'notifications',component:NotificationsComponent
            },
            {
                path:'comptraining',component:CompletedTrainingComponent
            },
            {
                path:'currtraining',component:CurrentTrainingComponent
            },
        
        ]
    }
];
@NgModule(
    {
        imports:[RouterModule,RouterModule.forChild(routes)],
        exports:[RouterModule]
    }
)
export class MentorRoutingModule{
    
}

