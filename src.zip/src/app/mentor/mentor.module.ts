import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuComponent } from './menu/menu.component';
import {EditskillComponent} from './menu/editskill/editskill.component'
import {MentorRoutingModule} from './mentor-routing.module';
import { CompletedTrainingComponent } from './menu/completed-training/completed-training.component';
import { CurrentTrainingComponent } from './menu/current-training/current-training.component';
import { SearchTrainingComponent } from './menu/search-training/search-training.component';
import { NotificationsComponent } from './menu/notifications/notifications.component'



@NgModule({
  declarations: [MenuComponent, EditskillComponent, CompletedTrainingComponent, CurrentTrainingComponent, SearchTrainingComponent, NotificationsComponent],
  imports: [
    CommonModule,MentorRoutingModule
  ]
})
export class MentorModule { }
