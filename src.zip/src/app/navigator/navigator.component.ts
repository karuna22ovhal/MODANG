import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import {RouterModule,Router} from '@angular/router';
import{UserMenuComponent} from '../user/user-menu/user-menu.component';
import { from } from 'rxjs';

@Component({
  selector: 'app-navigator',
  templateUrl: './navigator.component.html',
  styleUrls: ['./navigator.component.css']
})
export class NavigatorComponent implements OnInit {

  constructor(public authService:AuthService) { }

  ngOnInit() {
  }

}
