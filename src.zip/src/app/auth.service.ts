import { Injectable } from '@angular/core';
import {Router} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // credentials entity class
  // dummy collection of credential objects
  // collection can be updated from registration form /sign up form
  constructor(private router:Router) { }
  login(user:string, password: string, type:string): boolean{
    // perform credential chk
    // 1. interact with server // http module
    // 2. dummy checking
    if(user == "Rajat" && password == "abc" ){
      // HTML5 storage api
      localStorage.setItem("username", user);
      localStorage.setItem("type", type);
      return true;
    }
    return false;
  }

  logout(){
    localStorage.removeItem("username");
    localStorage.removeItem("type");
    
  }

  getUser(){
    return localStorage.getItem("username");
  }

  getType(){
    return localStorage.getItem("type");
  }

  isLoggedIn(): boolean{
    return localStorage.getItem("username") != null;
  }

  
}
