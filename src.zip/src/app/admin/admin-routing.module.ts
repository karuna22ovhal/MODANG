import { NgModule } from '@angular/core';
import { Routes,RouterModule} from '@angular/router';
import {UsrmngComponent} from './usrmng/usrmng.component';
import {CsrmngComponent} from './csrmng/csrmng.component';
import { AdminModule } from './admin.module';
import { ManagementComponent } from './management/management.component';

const routes:Routes=[
    {
        path:'admin',component:ManagementComponent,
        children:[
            {
                path:'usermng',component:UsrmngComponent
            },
            {
                path:'coursemng',component:CsrmngComponent
            }
        ]
    }
];
@NgModule(
    {
        imports:[RouterModule.forChild(routes)],
        exports:[RouterModule]
    }
)
export class AdminRoutingModule{
    
}

