import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-usrmng',
  templateUrl: './usrmng.component.html',
  styleUrls: ['./usrmng.component.css']
})
export class UsrmngComponent implements OnInit {

  constructor(public  authService:AuthService, private router:Router) { }
  logout(){
    this.authService.logout();
    this.router.navigate([''])
    // navigate programmatically to home as well
  }

  ngOnInit() {
  }

}
