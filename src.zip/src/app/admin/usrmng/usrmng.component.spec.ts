import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsrmngComponent } from './usrmng.component';

describe('UsrmngComponent', () => {
  let component: UsrmngComponent;
  let fixture: ComponentFixture<UsrmngComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsrmngComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsrmngComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
