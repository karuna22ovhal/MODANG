import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsrmngComponent } from './usrmng/usrmng.component';
import { CsrmngComponent } from './csrmng/csrmng.component';
import { ManagementComponent } from './management/management.component';
import { AdminRoutingModule } from './admin-routing.module';



@NgModule({
  declarations: [UsrmngComponent, CsrmngComponent, ManagementComponent],
  imports: [
    CommonModule,AdminRoutingModule
  ],
  bootstrap:[UsrmngComponent,CsrmngComponent,ManagementComponent]
})
export class AdminModule { }
