import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CsrmngComponent } from './csrmng.component';

describe('CsrmngComponent', () => {
  let component: CsrmngComponent;
  let fixture: ComponentFixture<CsrmngComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CsrmngComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsrmngComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
