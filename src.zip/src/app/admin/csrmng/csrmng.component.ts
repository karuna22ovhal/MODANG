import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csrmng',
  templateUrl: './csrmng.component.html',
  styleUrls: ['./csrmng.component.css']
})
export class CsrmngComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
