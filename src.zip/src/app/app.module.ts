import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Routes,RouterModule,} from '@angular/router';
import { AdminModule } from './admin/admin.module';
import { MentorModule } from './mentor/mentor.module';
import { UserModule } from './user/user.module';
import { LoginComponent } from './login/login.component';
import { AuthService } from './auth.service';
import { NavigatorComponent } from './navigator/navigator.component';
import {UserMenuComponent} from './user/user-menu/user-menu.component';
import { RegistrationComponent } from './registration/registration.component';
import { DashboardComponent } from './dashboard/dashboard.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NavigatorComponent,
    RegistrationComponent,
    DashboardComponent,
   
       
      ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AdminModule,
    MentorModule,
    UserModule,
    RouterModule,
  ],
  
  providers: [AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
