import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { AdminModule } from './admin/admin.module';
import { ManagementComponent } from './admin/management/management.component';
import { MenuComponent } from './mentor/menu/menu.component';
import { UserMenuComponent } from './user/user-menu/user-menu.component';
import { LoginComponent } from './login/login.component';
import { NavigatorComponent } from './navigator/navigator.component';
import { DashboardComponent } from './dashboard/dashboard.component';
const routes:Routes=[
  {
    path:'',component:DashboardComponent
  },
 
  {
    path:'login',component:LoginComponent
  },
  {
  path:'navi',component:NavigatorComponent},
   {
  path:'admin',component:ManagementComponent
  },
  {
  path:'mentor',component:MenuComponent 
  },
  {
  path:'user',component:UserMenuComponent
  
  },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: []
})
export class AppRoutingModule { }
