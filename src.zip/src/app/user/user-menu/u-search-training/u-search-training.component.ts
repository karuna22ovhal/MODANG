import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-u-search-training',
  templateUrl: './u-search-training.component.html',
  styleUrls: ['./u-search-training.component.css']
})
export class USearchTrainingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
