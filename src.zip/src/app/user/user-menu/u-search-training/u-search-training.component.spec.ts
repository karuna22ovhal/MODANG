import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { USearchTrainingComponent } from './u-search-training.component';

describe('USearchTrainingComponent', () => {
  let component: USearchTrainingComponent;
  let fixture: ComponentFixture<USearchTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ USearchTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(USearchTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
