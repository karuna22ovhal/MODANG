import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-u-current-training',
  templateUrl: './u-current-training.component.html',
  styleUrls: ['./u-current-training.component.css']
})
export class UCurrentTrainingComponent implements OnInit {

  constructor(public authService:AuthService) { }

  ngOnInit() {
  }

}
