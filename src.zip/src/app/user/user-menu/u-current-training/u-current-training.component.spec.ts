import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UCurrentTrainingComponent } from './u-current-training.component';

describe('UCurrentTrainingComponent', () => {
  let component: UCurrentTrainingComponent;
  let fixture: ComponentFixture<UCurrentTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UCurrentTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UCurrentTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
