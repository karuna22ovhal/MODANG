import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-u-completed-training',
  templateUrl: './u-completed-training.component.html',
  styleUrls: ['./u-completed-training.component.css']
})
export class UCompletedTrainingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
