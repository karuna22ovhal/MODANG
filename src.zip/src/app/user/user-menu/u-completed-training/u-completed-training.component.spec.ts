import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UCompletedTrainingComponent } from './u-completed-training.component';

describe('UCompletedTrainingComponent', () => {
  let component: UCompletedTrainingComponent;
  let fixture: ComponentFixture<UCompletedTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UCompletedTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UCompletedTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
