import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-u-notifications',
  templateUrl: './u-notifications.component.html',
  styleUrls: ['./u-notifications.component.css']
})
export class UNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
