import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UNotificationsComponent } from './u-notifications.component';

describe('UNotificationsComponent', () => {
  let component: UNotificationsComponent;
  let fixture: ComponentFixture<UNotificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UNotificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UNotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
