import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { UNotificationsComponent } from './user-menu/u-notifications/u-notifications.component';
import { UCompletedTrainingComponent } from './user-menu/u-completed-training/u-completed-training.component';
import { UCurrentTrainingComponent } from './user-menu/u-current-training/u-current-training.component';
import { USearchTrainingComponent } from './user-menu/u-search-training/u-search-training.component';
import { UserRoutingModule } from './user-routing.module';



@NgModule({
  declarations: [UserMenuComponent, UNotificationsComponent, UCompletedTrainingComponent, UCurrentTrainingComponent, USearchTrainingComponent],
  imports: [
    CommonModule,UserRoutingModule
  ],
  
})
export class UserModule { }
