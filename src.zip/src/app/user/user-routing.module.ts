import { NgModule } from '@angular/core';
import { Routes,RouterModule} from '@angular/router';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { USearchTrainingComponent } from './user-menu/u-search-training/u-search-training.component';
import { UNotificationsComponent } from './user-menu/u-notifications/u-notifications.component';
import { UCompletedTrainingComponent } from './user-menu/u-completed-training/u-completed-training.component';
import { UCurrentTrainingComponent } from './user-menu/u-current-training/u-current-training.component';

const routes:Routes=[
    {
        path:'usermenu',component:UserMenuComponent,
        children:[
            {
                path:'usearchtraining',component:USearchTrainingComponent
            },
            {
                path:'unotifications',component:UNotificationsComponent
            },
            {
                path:'ucomptraining',component:UCompletedTrainingComponent
            },
            {
                path:'ucurrtraining',component:UCurrentTrainingComponent
            },
        
        ]
    }
];
@NgModule(
    {
        imports:[RouterModule,RouterModule.forChild(routes)],
        exports:[RouterModule]
    }
)
export class UserRoutingModule{
    
}

